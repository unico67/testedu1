package day10;
public class ExceptionTest1 {
	public static void main(String[] args) {
		System.out.println("수행시작");
		
		System.out.println("수행종료");
	}
}
