package day3;

public class ForLab2 {
	public static void main(String[] args) {
		for(int i = 9; i > 3; i--) {
			if(i % 2 == 0) {
				System.out.println(i + ":짝수");
			}
			else {
				System.out.println(i + ":홀수");
			}
		}
	}
}
