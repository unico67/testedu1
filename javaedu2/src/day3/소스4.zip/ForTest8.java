package day3;

public class ForTest8 {      

	public static void main(String[] args) {
		int dan = 1;
		for(int num=1; num <= 9; num++)
			System.out.print(dan + "x" + num + "=" + dan*num + "\t");		
		System.out.println();
		dan = 2;
		for(int num=1; num <= 9; num++)
			System.out.print(dan + "x" + num + "=" + dan*num + "\t");		
		System.out.println();
		dan = 3;
		for(int num=1; num <= 9; num++)
			System.out.print(dan + "x" + num + "=" + dan*num + "\t");		
		System.out.println();
		dan = 4;
		for(int num=1; num <= 9; num++)
			System.out.print(dan + "x" + num + "=" + dan*num + "\t");		
		System.out.println();
		dan = 5;
		for(int num=1; num <= 9; num++)
			System.out.print(dan + "x" + num + "=" + dan*num + "\t");		
		System.out.println();
		dan = 6;
		for(int num=1; num <= 9; num++)
			System.out.print(dan + "x" + num + "=" + dan*num + "\t");		
		System.out.println();
		dan = 7;
		for(int num=1; num <= 9; num++)
			System.out.print(dan + "x" + num + "=" + dan*num + "\t");		
		System.out.println();
		dan = 8;
		for(int num=1; num <= 9; num++)
			System.out.print(dan + "x" + num + "=" + dan*num + "\t");		
		System.out.println();
		dan = 9;
		for(int num=1; num <= 9; num++)
			System.out.print(dan + "x" + num + "=" + dan*num + "\t");		
		System.out.println();
	}
}
