package day1;
public class OperTest2 {
	public static void main(String[] args) {
		int num=10;
		System.out.println(num);			
		System.out.println(++num);		
		System.out.println(++num);		
		System.out.println(++num);	
		System.out.println(num++);		
		System.out.println(num++);	
		System.out.println(num);
		System.out.println(--num);	
		System.out.println(num);				
		
	}
}
