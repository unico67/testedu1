package day1;

public class LiteralTest2 {

	public static void main(String[] args) {
		System.out.println("123456789t123456789t123456789");
		System.out.println("123456789\t123456789\t123456789");
		System.out.println("123456789n123456789n123456789");
		System.out.println("123456789\n123456789\n123456789");
		System.out.println("123456789\n\n123456789\n\n123456789");
		System.out.println("\n\n\n");
		System.out.println('가');
		System.out.println('나');
		System.out.println('다');
		System.out.println("\n\n\n");
		System.out.print('가');
		System.out.print('나');
		System.out.print('다');
	}
}
