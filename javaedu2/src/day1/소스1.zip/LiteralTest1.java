package day1;

public class LiteralTest1 {
	public static void main(String[] args) {		
		System.out.println(10);
		System.out.println(10.0);
		System.out.println(10.0f);
		System.out.println(10L);
		System.out.println(true);
		System.out.println(false);
		System.out.println('A');
		System.out.println("A");
		System.out.println('가');
		System.out.println("가");
		System.out.println("ABC");
		System.out.println("가나다");		
	}
}
