package day1;

public class VarTest1 {
	public static void main(String[] args) {
		int number1;
		//System.out.println(number1);
		int number2 = 123;
		System.out.println(number2);
		number1 = 10;
		System.out.println(number1);		
		System.out.println(number2+number1);
		System.out.println(number2-number1);
		System.out.println(number2*number1);
		System.out.println(number2/number1);
		System.out.println("number1 : "+number1);
	}
}
