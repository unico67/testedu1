package day1;
public class OperTest3 {
	public static void main(String[] args) {
		int num = (int)(Math.random() * 10) + 1; // 1~10
		char result = num % 2 == 1 ? '홀' : '짝';
		System.out.println(num+"은 "+result+"수입니다.");
		
		System.out.println(num+"은 "+(num % 2 == 1 ? '홀' : '짝')+"수입니다.");
	}
}
