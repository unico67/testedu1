package day1;
public class TypeTest1 {
	public static void main(String[] args) {
		System.out.println(1+1);
		System.out.println(1.0+1);
		System.out.println('1'+1);
		System.out.println("1"+1);
	}
}
