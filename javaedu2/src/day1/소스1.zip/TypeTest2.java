package day1;
public class TypeTest2 {
	public static void main(String[] args) {
		int num = 1000;
		System.out.println(1+num);
		System.out.println(1.0+num);
		System.out.println('1'+num);
		System.out.println("1"+num);
		System.out.println(7777777777L);
	}
}
