package day9.case1;

public class LgTV {
	public void turnOn(){
		System.out.println("LgTV --- 전원을 켠다.");
	}
	public void turnOff(){
		System.out.println("LgTV --- 전원을 끈다.");
	}
	public void soundUp(){
		System.out.println("LgTV --- 소리를 높인다.");
	}
	public void soundDown(){
		System.out.println("LgTV --- 소리를 낮춘다.");
	}

}
