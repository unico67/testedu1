package day4;

public class TwoArrayTest1 {
	public static void main(String[] args) {
		
	}
}



