package day4;

public class ArrayTest1 {

	public static void main(String[] args) {
		
	}

}
