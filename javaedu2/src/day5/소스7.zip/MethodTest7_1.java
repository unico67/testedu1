package day5;
public class MethodTest7_1 {
	public static void main(String[] args) {
		String result="";
		for(int i=0; i <args.length; i++)
			result = result + args[i];
		System.out.println(result);
	}	
}
